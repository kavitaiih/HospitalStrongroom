package TooldQA.artifactid;


public class mavenclass {

	
		

        

}
