package launchbrowser;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class class2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		// Extent report setup
		ExtentReports extent = new ExtentReports();
  ExtentSparkReporter spark = new ExtentSparkReporter("Transferin.html");
  extent.attachReporter(spark);

System.setProperty("webdriver.chrome.driver", "/home/user/Desktop/chromedriver");

WebDriver driver = new ChromeDriver();


driver.manage().window().maximize();



driver.get("https://hospital-staging.strongroom.ai/login");


//Display status log on html report page
extent.createTest("Go to https://hospital-staging.strongroom.ai/login").assignCategory("regression testing").assignDevice("Chrome")
.log(Status.INFO, "Go to https://hospital-staging.strongroom.ai/login");


driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));


WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));



driver.findElement(By.xpath("//input[@placeholder='Location']")).sendKeys("Orange Hospital");



WebElement clickElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='drug-search-result' and text()='Orange Hospital']")));
clickElement.click();
	    

WebElement field2 = driver.findElement(By.xpath("//input[@placeholder='Username/email']"));

field2.sendKeys("qa@strongroom.ai");

WebElement field3 = driver.findElement(By.xpath("//input[@placeholder='Password']"));

field3.sendKeys("stew-dazzling-washtub!");


WebElement Loginbtn = driver.findElement(By.xpath("//p[@class='blue-button']"));

Loginbtn.click();

Thread.sleep(2000);


WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
dropdown.click();

WebElement dropdown1= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]")));
dropdown1.click();

Thread.sleep(2000);

WebElement	locationbtn=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
locationbtn.click();

WebElement	transferin=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Transfer In']")));
transferin.click();

Thread.sleep(2000);

 WebElement drpdwn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
 WebElement drpdwn1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Type in location to receive from']")));

drpdwn1.sendKeys("Emergency Ward");
 drpdwn.click();
 		 
 
 WebElement option1clicked = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@aria-label='Emergency Ward']")));
 option1clicked.click();

 WebElement notes = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='note-modal']")));

 notes.sendKeys("Notes Will be here");
 
 Thread.sleep(2000);
 
 WebElement	bluebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Imprest/Emergency Meds/Ward Stock']")));
 bluebtn.click();

 
 WebElement drpdwn2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[contains(@placeholder,'Select Medication')]")));
 WebElement drpdwn3 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'right-form-section-drug-entry')]//div//span[contains(@class,'p-dropdown-trigger-icon pi pi-chevron-down')]")));

 drpdwn2.sendKeys("(guaifenesin) guaifenesin 100 mg/5 mL oral liquid");
 drpdwn3.click();
 
 Thread.sleep(2000);
 
 WebElement option1clicked2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@aria-label,'(guaifenesin) guaifenesin 100 mg/5 mL oral liquid')]")));
 option1clicked2.click();
 		
 WebElement qty = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Qty...']")));

 qty.sendKeys("1");
 
 Thread.sleep(2000);
 
 WebElement addclicked = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
 addclicked.click();
 
 
 Thread.sleep(2000);
 
 WebElement receivetranferbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Receive Transfer + New']")));
 receivetranferbtn.click();
 
 
 Thread.sleep(2000);
 
 
 WebElement pwd = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Password']")));

 pwd.sendKeys("1111");
 
 
 Thread.sleep(2000);

 WebElement signinbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='green-button']")));
 signinbtn.click();
 
 Thread.sleep(2000);
 
 WebElement completebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h3[normalize-space()='Complete']")));
 completebtn.click();
 
 extent.flush();

 //driver.quit();

		
	}

}
