package launchbrowser;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class PatientMedicationClass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		ExtentReports extent = new ExtentReports();
		  ExtentSparkReporter spark = new ExtentSparkReporter("Transferin.html");
		  extent.attachReporter(spark);

		System.setProperty("webdriver.chrome.driver", "/home/user/Desktop/chromedriver");
	
		WebDriver driver = new ChromeDriver();
		
	
		driver.manage().window().maximize();
		
		

		driver.get("https://hospital-staging.strongroom.ai/login");
		
		extent.createTest("Go to https://hospital-staging.strongroom.ai/login").assignCategory("regression testing").assignDevice("Chrome")
		.log(Status.INFO, "Go to https://hospital-staging.strongroom.ai/login");
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));
		
		
		
		driver.findElement(By.xpath("//input[@placeholder='Location']")).sendKeys("Orange Hospital");
		
		
	
	    WebElement clickElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='drug-search-result' and text()='Orange Hospital']")));
	    clickElement.click();
			    
	    
		WebElement field2 = driver.findElement(By.xpath("//input[@placeholder='Username/email']"));
		
		field2.sendKeys("qa@strongroom.ai");
		
        WebElement field3 = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		
		field3.sendKeys("stew-dazzling-washtub!");
		
		
		WebElement Loginbtn = driver.findElement(By.xpath("//p[@class='blue-button']"));
		
		Loginbtn.click();

		Thread.sleep(2000);
		

		WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		dropdown.click();
		
		WebElement dropdown1= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]")));
		dropdown1.click();
		
		Thread.sleep(2000);
		
		WebElement	locationbtn=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
		locationbtn.click();
		
		WebElement	transferin =  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Transfer In']")));
		transferin.click();
		
		Thread.sleep(2000);
		
		WebElement	transferin1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Patient Medication']")));
		transferin1.click();
		
		
		WebElement	clicksearchbar = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Enter Patient name or Medicare Number']")));
		clicksearchbar.click();
		
		clicksearchbar.sendKeys("a" + Keys.ENTER);
		
		WebElement	clickresult = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='patient-result-info']//p[1]")));
		clickresult.click();
				
		Thread.sleep(2000);
		
		WebElement drpdwn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='left-form-section-panel']//div//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		 WebElement drpdwn1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Type in location to receive from']")));

		drpdwn1.sendKeys("Emergency Ward");
		 drpdwn.click();
		
		 Thread.sleep(2000);
		 
		 WebElement option1clicked = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@aria-label='Emergency Ward']")));
		 option1clicked.click();
		 
		 
		WebElement notes = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='note-modal']")));

		 notes.sendKeys("Notes Will be here");
		 
		 
		 WebElement  prescribername = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Enter Prescriber No. or Name']")));
		 prescribername.click();
		 
		 Thread.sleep(2000);

		 
		 WebElement addspace = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Enter Prescriber No. or Name']")));
		 addspace.sendKeys(" ");

		 Thread.sleep(1000);

		 
		 WebElement resultclicked = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Reference only - vishal parmar']")));
		 resultclicked.click();
		 
		 Thread.sleep(2000);
		 
		 
		 WebElement obj2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Select Medication']")));

			WebElement obj1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='p-dropdown p-component p-inputwrapper']//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
			
			obj2.sendKeys("1");

			 obj1.click();
			 
			 WebElement medclicked = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@aria-label='(methadone) methadone hydrochloride 10 mg/mL injection, vial']")));
			 medclicked.click();
			 
			 WebElement qtyclick = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Qty...']")));
			 qtyclick.click();
			 
			 Thread.sleep(2000);

			 
			 WebElement qty = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Qty...']")));

			 qty.sendKeys("1");
			 
			 Thread.sleep(2000);

			 
			 WebElement addclicked = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
			 addclicked.click();
			 
			 Thread.sleep(2000);
			 
			 WebElement receivetranferbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Receive Transfer']")));
			 receivetranferbtn.click();
			 
			 
			 Thread.sleep(2000);
			 
			 WebElement pwd = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Password']")));

			 pwd.sendKeys("1111");
			 
			 
			 Thread.sleep(2000);
			
			 WebElement signinbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='green-button']")));
			 signinbtn.click();
			 
			 Thread.sleep(2000);
			 
			 WebElement completebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h3[normalize-space()='Complete']")));
			 completebtn.click();
			 
			 extent.flush();
			 

	}

}
