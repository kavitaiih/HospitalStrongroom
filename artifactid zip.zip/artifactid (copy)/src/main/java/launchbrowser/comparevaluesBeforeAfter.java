package launchbrowser;

import java.time.Duration;


import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;


public class comparevaluesBeforeAfter {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

//Log in Process

		ExtentReports extent = new ExtentReports();
		ExtentSparkReporter spark = new ExtentSparkReporter("TransferOUTPatient.html");
		extent.attachReporter(spark);

		// System.setProperty("webdriver.chrome.driver",
		// "/home/user/Desktop/chromedriver");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://hospital-staging.strongroom.ai/login");
		System.out.println("process complete");

		// Display status log on html report page
		extent.createTest("Go to https://hospital-staging.strongroom.ai/login").assignCategory("TransferOUTpatient")
				.assignDevice("Chrome").log(Status.INFO, "Go to https://hospital-staging.strongroom.ai/login");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));

		driver.findElement(By.xpath("//input[@placeholder='Location']")).sendKeys("Orange Hospital");

		WebElement clickElement = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//p[@class='drug-search-result' and text()='Orange Hospital']")));
		clickElement.click();

		WebElement field2 = driver.findElement(By.xpath("//input[@placeholder='Username/email']"));

		field2.sendKeys("qa@strongroom.ai");

		WebElement field3 = driver.findElement(By.xpath("//input[@placeholder='Password']"));

		field3.sendKeys("stew-dazzling-washtub!");

		WebElement Loginbtn = driver.findElement(By.xpath("//p[@class='blue-button']"));

		Loginbtn.click();

		extent.createTest("Login successfully").assignCategory("TransferOUTpatient").assignDevice("Chrome")
				.log(Status.INFO, "Login successfully");

		Thread.sleep(2000);

		WebElement dropdown = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		dropdown.click();

		WebElement dropdown1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[3]")));
		dropdown1.click();

		Thread.sleep(2000);

		WebElement locationbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
		locationbtn.click();

		extent.createTest(" Go to /drug-register").assignCategory("TransferOUTpatient").assignDevice("Chrome")
				.log(Status.INFO, " Go to /drug-register");
		Thread.sleep(2000);
		

//Check the stock on the medidcation
		

		WebElement medidcationfilter = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Medication...']")));
		medidcationfilter.click();
		medidcationfilter.sendKeys("guaifenesin 100 mg/5 mL oral liquid");

		Thread.sleep(2000);
		
		WebElement NotificationBTN = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='new-patient-button data-v-tooltip']//i[@class='pi pi-exclamation-circle']")));
		NotificationBTN.click();
		

		WebElement ImprestONLYbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Imprest Only']")));
		ImprestONLYbtn.click();


		Thread.sleep(2000);
		
// Print the Present available balance of that Medicaiton

        WebElement AvailableBalance = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@style='width: 80px;']")));

        // Get the text content of the element and print it

        String stock = AvailableBalance.getText();

        System.out.println("(guaifenesin) guaifenesin 100 mg/5 mL oral liquid(Stock): " + stock);
		

        Thread.sleep(2000);
        
        
        
// Process OF Transfer IN

		WebElement TrabsferIN = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Transfer In']")));
		TrabsferIN.click();

		Thread.sleep(2000);

		extent.createTest("Click the Transfer IN button in the left menu").assignCategory("OutgoingImprest")
				.assignDevice("Chrome").log(Status.INFO, "Click the Transfer IN button in the left menu");
		Thread.sleep(2000);

		WebElement drpdwn = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		WebElement drpdwn1 = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//input[@placeholder='Type in location to receive from']")));

		drpdwn1.sendKeys("Emergency Ward");
		drpdwn.click();
		extent.createTest("Enter a location").assignCategory("TransferINimprest").assignDevice("Chrome")
				.log(Status.INFO, "Enter a location");

		Thread.sleep(2000);

		WebElement locationselect = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@aria-label='Emergency Ward']")));
		locationselect.click();

		extent.createTest("Select a location").assignCategory("TransferINimprest").assignDevice("Chrome")
				.log(Status.INFO, "Select a location");



		WebElement addnotes = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='note-modal']")));

		addnotes.sendKeys("Notes Will be here");

		Thread.sleep(2000);

		extent.createTest("Add text to notes").assignCategory("OutgoingImprest").assignDevice("Chrome").log(Status.INFO,
				"Add text to notes");

		Thread.sleep(2000);

		WebElement IMprestbtn = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//p[normalize-space()='Imprest/Emergency Meds/Ward Stock']")));
		IMprestbtn.click();

		extent.createTest("Click the Imprest/Emergancy Meds/Ward Stock button").assignCategory("OutgoingImprest")
				.assignDevice("Chrome").log(Status.INFO, "Click the Imprest/Emergancy Meds/Ward Stock button");

		Thread.sleep(2000);
		
		WebElement drpdwn2 = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//input[contains(@placeholder,'Select Medication')]")));
		WebElement drpdwn3 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//div[contains(@class,'right-form-section-drug-entry')]//div//span[contains(@class,'p-dropdown-trigger-icon pi pi-chevron-down')]")));

		drpdwn2.sendKeys("(guaifenesin) guaifenesin 100 mg/5 mL oral liquid");

		drpdwn3.click();

		Thread.sleep(2000);

		WebElement selectmedication = wait.until(ExpectedConditions.elementToBeClickable(
				By.xpath("//li[contains(@aria-label,'(guaifenesin) guaifenesin 100 mg/5 mL oral liquid')]")));
		selectmedication.click();
		extent.createTest("Enter a medication").assignCategory("TransferINimprest").assignDevice("Chrome")
				.log(Status.INFO, "Enter a medication");

		WebElement qty = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Qty...']")));

		qty.sendKeys("1");
		extent.createTest("Select a medication and qty").assignCategory("TransferINimprest").assignDevice("Chrome")
				.log(Status.INFO, "Select a medication and qty");
		Thread.sleep(2000);

		WebElement addbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
		addbtn.click();
		extent.createTest("Click the Add button").assignCategory("TransferINimprest").assignDevice("Chrome")
				.log(Status.INFO, "Click the Add button");

		Thread.sleep(2000);
		
		WebElement AddedBalance  = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='right-form-section-drug-container']//span[1]")));

        // Get the text content of the element and print it

        String add = AddedBalance.getText();

        System.out.println("(guaifenesin)Guaifenesin 100 mg/5 mL oral liquid): " + add);
        
        Thread.sleep(1000);
        
        
        try {
            // Retrieve the text value of the first element
            String value1 = AvailableBalance.getText();
            System.out.println("Value1: " + value1);

            // Retrieve the text value of the second element
            String value2 = AddedBalance.getText();
            System.out.println("Value2: " + value2);

            // Check for null values
            if (value1 != null && value2 != null) {
                // Convert the text values to numeric format (assuming they are numbers)
                int intValue1 = Integer.parseInt(value1);
                int intValue2 = Integer.parseInt(value2);

                // Perform addition of the values
                int result = intValue1 + intValue2;

                // Print the result or perform further actions
                System.out.println("Result of addition: " + result);
            } else {
                System.err.println("Error: One or both of the values are null.");
                // Handle the error or inform the user accordingly
            }
        } catch (NumberFormatException e) {
            System.err.println("Error: One or both of the values are not valid integers.");
            e.printStackTrace();  // Print the stack trace for more details
            // Handle the exception or inform the user accordingly
        }

		WebElement receivetranferbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Receive Transfer']")));
		receivetranferbtn.click();

		extent.createTest("Click the Recieve Transfer button").assignCategory("TransferINimprest")
				.assignDevice("Chrome").log(Status.INFO, "Click the Recieve Transfer button");

		Thread.sleep(2000);

		WebElement pwd = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Password']")));

		pwd.sendKeys("1111");

		Thread.sleep(2000);

		WebElement signinbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='green-button']")));
		signinbtn.click();

		extent.createTest("Enter correct signature and click the Sign button").assignCategory("TransferINimprest")
				.assignDevice("Chrome").log(Status.INFO, "Enter correct signature and click the Sign button");

		Thread.sleep(2000);

		WebElement completebtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//h3[normalize-space()='Complete']")));
		completebtn.click();

		Thread.sleep(2000);

		extent.createTest("Click on complete button ").assignCategory("TransferINimprest").assignDevice("Chrome")
				.log(Status.INFO, "Click on complete button ");

		
		String mednamedynamic = driver
				.findElement(By.xpath(
						"/html[1]/body[1]/div[1]/div[1]/div[3]/div[2]/div[1]/div[3]/table[1]/tbody[1]/tr[1]/td[3]"))
				.getText();
		
		Thread.sleep(2000);

		//Print the total balance after the transaction
		
		 WebElement TotalBalance = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@style='width: 80px;']")));



	        // Get the text content of the element and print it

	        
	        Thread.sleep(2000);
	        
	/*
	        
	     // Retrieve the text value of the first element
	        String value1 = AvailableBalance.getText();

	        // Convert the text value to a numeric format (assuming it's a number)
	        int intValue1 = Integer.parseInt(value1);

	       

	        // Retrieve the text value of the second element
	        String value2 = AddedBalance.getText();

	        // Convert the text value to a numeric format (assuming it's a number)
	        int intValue2 = Integer.parseInt(value2);

	        // Perform addition of the values
	        int result = intValue1 + intValue2;

	        // Print the result or perform further actions
	        System.out.println("Result of addition: " + result);

		

	        
	        try {
	            // Retrieve the text value of the first element
	            String value1 = AvailableBalance.getText();
	            
	            try {
	                // Your WebDriver code here
	            } catch (WebDriverException e) {
	                e.printStackTrace();
	            }

	            // Convert the text value to a numeric format (assuming it's a number)
	            int intValue1 = Integer.parseInt(value1);

	            // Retrieve the text value of the second element
	            String value2 = AddedBalance.getText();

	            // Convert the text value to a numeric format (assuming it's a number)
	            int intValue2 = Integer.parseInt(value2);

	            // Perform addition of the values
	            int result = intValue1 + intValue2;

	            // Print the result or perform further actions
	            System.out.println("Result of addition: " + result);
	        } catch (NumberFormatException e) {
	            System.err.println("Error: One or both of the values are not valid integers.");
	            // Handle the exception or inform the user accordingly
	        }
        
        extent.flush();
        
       
        
        
        /*
//Check again the balance on the "Drug register " screen of that medication ,it should be 0

		WebElement medidcationfilter1 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Medication...']")));
		medidcationfilter1.click();
		medidcationfilter1.sendKeys("doxazosin 4mg/each");

		Thread.sleep(2000);

		WebElement SearchBTN2 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='button submit-button']")));
		SearchBTN2.click();

		Thread.sleep(2000);

		WebElement cLICKONrow1 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody[1]/tr[1]/td[1]/i[1]]")));
		cLICKONrow1.click();

		extent.createTest("Click the 1st row of the data to check the final balanc of the searched medication")
				.assignCategory("OutgoingImprest").assignDevice("Chrome")
				.log(Status.INFO, "Click the 1st row of the data to check the final balanc of the searched medication");
		Thread.sleep(2000);

		System.out.println("Now After the outgoing process the available balance should be 0");
		
		*/

	}

}
