package launchbrowser;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.interactions.Actions;

public class AdjustmentPatient {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		ExtentReports extent = new ExtentReports();
		ExtentSparkReporter spark = new ExtentSparkReporter("AdjustmentPATIENT.html");
		extent.attachReporter(spark);

		// System.setProperty("webdriver.chrome.driver",
		// "/home/user/Desktop/chromedriver");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://hospital-staging.strongroom.ai/login");

		extent.createTest("Go to https://hospital-staging.strongroom.ai/login").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "Go to https://hospital-staging.strongroom.ai/login");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));

		driver.findElement(By.xpath("//input[@placeholder='Location']")).sendKeys("Orange Hospital");

		WebElement clickElement = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//p[@class='drug-search-result' and text()='Orange Hospital']")));
		clickElement.click();

		WebElement field2 = driver.findElement(By.xpath("//input[@placeholder='Username/email']"));

		field2.sendKeys("qa@strongroom.ai");

		WebElement field3 = driver.findElement(By.xpath("//input[@placeholder='Password']"));

		field3.sendKeys("stew-dazzling-washtub!");

		WebElement Loginbtn = driver.findElement(By.xpath("//p[@class='blue-button']"));

		Loginbtn.click();

		Thread.sleep(2000);

		WebElement dropdown = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		dropdown.click();

		WebElement dropdown1 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@aria-label,'Pharmacy')]")));
		dropdown1.click();

		Thread.sleep(2000);

		WebElement selectlocationbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='blue-button']")));
		selectlocationbtn.click();

		extent.createTest("Go to /drug-register").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Go to /drug-register");

		Thread.sleep(2000);

//Transfer IN process

		/*
		 * WebElement transferin = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.
		 * xpath("//button[normalize-space()='Transfer In']"))); transferin.click();
		 * 
		 * Thread.sleep(2000);
		 * 
		 * extent.createTest("Click the Transfer In button in the left menu").
		 * assignCategory("AdjustmentPATIENT") .assignDevice("Chrome").log(Status.INFO,
		 * "Click the Transfer In button in the left menu");
		 * 
		 * WebElement drpdwn = wait.until(ExpectedConditions .elementToBeClickable(By.
		 * xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		 * WebElement drpdwn1 = wait.until(ExpectedConditions .elementToBeClickable(By.
		 * xpath("//input[@placeholder='Type in location to receive from']")));
		 * 
		 * drpdwn1.sendKeys("Emergency Ward"); drpdwn.click();
		 * extent.createTest("Enter a location").assignCategory("AdjustmentPATIENT").
		 * assignDevice("Chrome") .log(Status.INFO, "Enter a location");
		 * 
		 * Thread.sleep(2000);
		 * 
		 * WebElement locationselect = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.
		 * xpath("//li[@aria-label='Emergency Ward']"))); locationselect.click();
		 * 
		 * extent.createTest("Select a location").assignCategory("AdjustmentPATIENT").
		 * assignDevice("Chrome") .log(Status.INFO, "Select a location");
		 * 
		 * WebElement addnotes = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//textarea[@id='note-modal']")));
		 * 
		 * addnotes.sendKeys("Notes Will be here");
		 * 
		 * Thread.sleep(2000);
		 * 
		 * extent.createTest("Add text to notes").assignCategory("AdjustmentPATIENT").
		 * assignDevice("Chrome") .log(Status.INFO, "Add text to notes");
		 * 
		 * WebElement Patientmedicationbtn = wait.until(
		 * ExpectedConditions.elementToBeClickable(By.
		 * xpath("//p[normalize-space()='Patient Medication']")));
		 * Patientmedicationbtn.click();
		 * extent.createTest("Click the Patient Medication button ").assignCategory(
		 * "AdjustmentPATIENT") .assignDevice("Chrome").log(Status.INFO,
		 * " Click the Patient Medication button"); Thread.sleep(2000);
		 * 
		 * WebElement patientname = wait.until(ExpectedConditions
		 * .elementToBeClickable(By.
		 * xpath("//input[@placeholder='Enter Patient name or Medicare Number']")));
		 * patientname.click(); patientname.sendKeys("k" + Keys.ENTER); extent.
		 * createTest("Enter a patient name in the search field and click search ")
		 * .assignCategory("AdjustmentPATIENT").assignDevice("Chrome") .log(Status.INFO,
		 * " Enter a patient name in the search field and click search");
		 * Thread.sleep(2000);
		 * 
		 * WebElement clickresult = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//div[@class='patient-result-info']//p[1]"))); clickresult.click();
		 * Thread.sleep(2000);
		 * 
		 * WebElement prescribername = wait.until(ExpectedConditions
		 * .elementToBeClickable(By.
		 * xpath("//input[@placeholder='Enter Prescriber No. or Name']")));
		 * prescribername.click();
		 * extent.createTest("Enter Prescriber name ").assignCategory(
		 * "AdjustmentPATIENT").assignDevice("Chrome") .log(Status.INFO,
		 * "Enter Prescriber name"); Thread.sleep(2000);
		 * 
		 * WebElement addspace = wait.until(ExpectedConditions .elementToBeClickable(By.
		 * xpath("//input[@placeholder='Enter Prescriber No. or Name']")));
		 * addspace.sendKeys(" "); Thread.sleep(1000);
		 * 
		 * WebElement resultclicked = wait.until(
		 * ExpectedConditions.elementToBeClickable(By.
		 * xpath("//p[normalize-space()='Reference only - Jim jam']")));
		 * resultclicked.click(); Thread.sleep(1000);
		 * 
		 * // Click on the dropdown to open it WebElement dropdownTrigger =
		 * driver.findElement(By.xpath(
		 * "//div[@class='right-form-section-drug-entry']//div//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']"
		 * )); dropdownTrigger.click();
		 * 
		 * WebElement drpdwn2 = wait.until(ExpectedConditions .elementToBeClickable(By.
		 * xpath("//input[contains(@placeholder,'Select Medication')]"))); WebElement
		 * drpdwn3 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//div[contains(@class,'right-form-section-drug-entry')]//div//span[contains(@class,'p-dropdown-trigger-icon pi pi-chevron-down')]"
		 * )));
		 * 
		 * drpdwn2.sendKeys("(guaifenesin) guaifenesin 100 mg/5 mL oral liquid");
		 * 
		 * drpdwn3.click();
		 * 
		 * Thread.sleep(2000);
		 * 
		 * WebElement selectmedication =
		 * wait.until(ExpectedConditions.elementToBeClickable( By.
		 * xpath("//li[contains(@aria-label,'(guaifenesin) guaifenesin 100 mg/5 mL oral liquid')]"
		 * ))); selectmedication.click();
		 * extent.createTest("Enter a medication").assignCategory("AdjustmentPATIENT").
		 * assignDevice("Chrome") .log(Status.INFO, "Enter a medication");
		 * 
		 * WebElement qty = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//input[@placeholder='Qty...']")));
		 * 
		 * qty.sendKeys("1000");
		 * extent.createTest("Select a medication and qty").assignCategory(
		 * "AdjustmentPATIENT").assignDevice("Chrome") .log(Status.INFO,
		 * "Select a medication and qty"); Thread.sleep(2000);
		 * 
		 * WebElement addbtn =
		 * wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//p[@class='blue-button']"))); addbtn.click();
		 * extent.createTest("Click the Add button").assignCategory("AdjustmentPATIENT")
		 * .assignDevice("Chrome") .log(Status.INFO, "Click the Add button");
		 * 
		 * Thread.sleep(2000);
		 * 
		 * WebElement receivetranferbtn = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.
		 * xpath("//p[normalize-space()='Receive Transfer']")));
		 * receivetranferbtn.click();
		 * 
		 * extent.createTest("Click the Recieve Transfer button").assignCategory(
		 * "AdjustmentPATIENT") .assignDevice("Chrome").log(Status.INFO,
		 * "Click the Recieve Transfer button");
		 * 
		 * Thread.sleep(2000);
		 * 
		 * WebElement pwd = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//input[@placeholder='Password']")));
		 * 
		 * pwd.sendKeys("1111");
		 * 
		 * Thread.sleep(2000);
		 * 
		 * WebElement signinbtn = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//div[@class='green-button']"))); signinbtn.click();
		 * 
		 * extent.createTest("Enter correct signature and click the Sign button").
		 * assignCategory("AdjustmentPATIENT") .assignDevice("Chrome").log(Status.INFO,
		 * "Enter correct signature and click the Sign button");
		 * 
		 * Thread.sleep(2000);
		 * 
		 * WebElement completebtn = wait
		 * .until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//h3[normalize-space()='Complete']"))); completebtn.click();
		 * 
		 * Thread.sleep(2000);
		 * 
		 * extent.createTest("Click on complete button ").assignCategory(
		 * "AdjustmentPATIENT").assignDevice("Chrome") .log(Status.INFO,
		 * "Click on complete button ");
		 * 
		 * extent.flush();
		 * 
		 */

//Process of balance check and copy the transaction ID from Drug register  on the stocktake screen		

		WebElement stockbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Stock']")));
		stockbtn.click();

		extent.createTest("Click on the stock button at the top of the menu").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "Click on the stock button at the top of the menu");

		Thread.sleep(2000);

		WebElement stockTakebtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Stocktake']")));
		stockTakebtn.click();

		extent.createTest("Click on the stocktake button of submenu of stock").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "Click on the stocktake button of submenu of stock");

		Thread.sleep(2000);

		WebElement clickonpatientFilter = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Patient...']")));
		clickonpatientFilter.click();
		clickonpatientFilter.sendKeys("kammo");

		extent.createTest("Click on the patient filter to search the particular patient ")
				.assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Click on the patient filter to search the particular patient");

		Thread.sleep(2000);

		WebElement ClickonSEARCHbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='button submit-button']")));
		ClickonSEARCHbtn.click();

		Thread.sleep(2000);

		WebElement clickonenterCOUNT = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[2]//td[5]//input[1]")));
		clickonenterCOUNT.click();
		clickonenterCOUNT.sendKeys("10");

		extent.createTest("Click on the Enter count input field and enter the amount ")
				.assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Click on the Enter count input field and enter the amount");

		Thread.sleep(2000);

		WebElement addNotes = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@placeholder='Notes']")));
		addNotes.click();
		addNotes.sendKeys("Mistchmatch of medication count ");

		extent.createTest("Add notes ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome").log(Status.INFO,
				"Add notes");

		Thread.sleep(2000);

		WebElement clickonBalanceCheckbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='submit-button']")));
		clickonBalanceCheckbtn.click();

		extent.createTest("Click on Balance Check button ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Click on Balance Check button");

		Thread.sleep(2000);

		WebElement Enterpassword = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Password']")));

		Enterpassword.sendKeys("1111");

		Thread.sleep(2000);

		WebElement signinbtn1 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='green-button']")));
		signinbtn1.click();

		extent.createTest("1. Enter correct signature and click the Sign button").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "1. Enter correct signature and click the Sign button");

		Thread.sleep(2000);

		WebElement EnterUSERNAME = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Username']")));

		EnterUSERNAME.sendKeys("nathan");

		WebElement Enterpass = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Password']")));

		Enterpass.sendKeys("1111");

		Thread.sleep(2000);

		WebElement signinbtn2 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='green-button']")));
		signinbtn2.click();

		extent.createTest("2. Enter correct signature and click the Sign button").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "2. Enter correct signature and click the Sign button");

		Thread.sleep(2000);

		WebElement DrugRegister = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Drug Register']")));
		DrugRegister.click();

		extent.createTest("Click On the drug register").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Click On the drug register");

		Thread.sleep(2000);

		WebElement ClickARROW = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[normalize-space()='Balance check']")));
		ClickARROW.click();

		extent.createTest("Check for new balance check ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Check for new balance check");

		Thread.sleep(2000);

		WebElement ClicKONcopybtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='blue-button copy-button']")));
		ClicKONcopybtn.click();

		extent.createTest("Copy Transaction ID ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Copy Transaction ID");

		Thread.sleep(2000);

//Process of Adjustment

		WebElement Adjusmentbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Adjustment']")));
		Adjusmentbtn.click();

		extent.createTest("Click on the Adjustment tab form the left side menu ").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "Click on the Adjustment tab form the left side menu");

		Thread.sleep(2000);

		WebElement PasteTransID = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Transaction ID...']")));
		PasteTransID.click();

		WebElement targetElement = driver.findElement(By.xpath("//input[@placeholder='Transaction ID...']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(targetElement).keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).build().perform();

		extent.createTest("Paste the copied Transaction ID ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, "Paste the copied Transaction ID");

		Thread.sleep(2000);

		WebElement addnotes = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='note-modal']")));

		addnotes.sendKeys("Notes Will be here");

		Thread.sleep(2000);

		WebElement Patientmedicationbtn = wait.until(
				ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Patient Medication']")));
		Patientmedicationbtn.click();
		extent.createTest("Click the Patient Medication button ").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, " Click the Patient Medication button");
		Thread.sleep(2000);

		WebElement patientname = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//input[@placeholder='Enter Patient name or Medicare Number']")));
		patientname.click();
		patientname.sendKeys("k" + Keys.ENTER);
		extent.createTest("Enter a patient name in the search field and click search ")
				.assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, " Enter a patient name in the search field and click search");
		Thread.sleep(2000);

		WebElement clickresult = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='patient-result-info']//p[1]")));
		clickresult.click();
		Thread.sleep(2000);

		WebElement medicationdrp = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//span[@class='p-dropdown-trigger-icon pi pi-chevron-down']")));
		medicationdrp.click();

		extent.createTest("Enter a medication ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, " Enter a medication");

		Thread.sleep(2000);

		WebElement selectmedication = wait.until(ExpectedConditions.elementToBeClickable(By
				.xpath("//li[@aria-label='glimepiride 2 mg tablet']//div[@class='ingredient-item']//div[1]//div[1]")));
		selectmedication.click();
		Thread.sleep(2000);

		WebElement addbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='submit-button blue-button']")));
		addbtn.click();
		Thread.sleep(2000);

		WebElement EntermedicationAmount = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='number']")));
		EntermedicationAmount.click();
		EntermedicationAmount.sendKeys("10");

		extent.createTest("Enter a medication Amount ").assignCategory("AdjustmentPATIENT").assignDevice("Chrome")
				.log(Status.INFO, " Enter a medication Amount");

		Thread.sleep(2000);

		WebElement Submitbtn = wait.until(
				ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='regular-button complete-button']")));
		Submitbtn.click();
		Thread.sleep(2000);

		WebElement pass1 = wait.until(ExpectedConditions
				.elementToBeClickable(By.xpath("//div[@class='form-section-container']//div//div[1]//input[2]")));
		pass1.click();
		pass1.sendKeys("1111");

		extent.createTest("1. Enter correct signature and click the Sign button").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "1. Enter correct signature and click the Sign button");

		Thread.sleep(2000);

		WebElement sign1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//div[@class='modal-mask']//div[@class='modal-mask']//div[@class='form-section-container']//div//div[1]//div[1]")));
		sign1.click();
		Thread.sleep(2000);

		WebElement EnterUSERNAME1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//body//div[@id='app']//div[@class='modal-mask']//div[@class='modal-mask']//div[@class='modal-body']//div[2]//input[1]")));

		EnterUSERNAME1.sendKeys("nathan");

		WebElement Enterpass1 = wait.until(
				ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='modal-body']//div[2]//input[2]")));

		Enterpass1.sendKeys("1111");

		Thread.sleep(2000);

		WebElement sign2 = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='green-button']")));
		sign2.click();

		extent.createTest("2. Enter correct signature and click the Sign button").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "2. Enter correct signature and click the Sign button");

		Thread.sleep(3000);

		WebElement clickonArrow = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody[1]/tr[1]/td[1]/i[1]")));
		clickonArrow.click();
		
		Thread.sleep(2000);
		
		//Verify the same medication Adjustment in the stocktake
		
		WebElement clickonStock = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Stock']")));
		clickonStock.click();

		extent.createTest("Go to Stock -> Stock Take").assignCategory("AdjustmentPATIENT")
				.assignDevice("Chrome").log(Status.INFO, "Go to Stock -> Stock Take");
		
		Thread.sleep(2000);
		
		WebElement clickonStockTake = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Stocktake']")));
		clickonStockTake.click();
		Thread.sleep(2000);
		
		WebElement medicationFilter = wait
		.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Medication...']")));
		medicationFilter.click();
		medicationFilter.sendKeys("glimepiride 2 mg tablet");
		
		Thread.sleep(2000);
		
		WebElement PatientFilter = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Patient...']")));
		PatientFilter.click();
		PatientFilter.sendKeys("kammo");
		
		Thread.sleep(2000);
		
		WebElement ClickonIncludeS8BTN = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[@class='active-select-filter select-filter-item']")));
		ClickonIncludeS8BTN.click();
		
		Thread.sleep(2000);
		
		WebElement ClickonDisplstockbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Display In Stock Only']")));
		ClickonDisplstockbtn.click();
		
		Thread.sleep(2000);
		
		WebElement ClickonSearchbtn = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='button submit-button']")));
		ClickonSearchbtn.click();
		
		Thread.sleep(2000);
		
		
	

		
		extent.flush();

	}

}
